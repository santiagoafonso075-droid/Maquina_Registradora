# =============================================================
# views/login.py — Ecrã de Login
# =============================================================

import os
import sys
import customtkinter as ctk
from PIL import Image, ImageTk

from config import CORES, FONTES, LARGURA, ALTURA
from utils.data_manager import verificar_credenciais, registar_inicio_sessao


def _get_logo_path() -> str:
    if getattr(sys, "frozen", False):
        base = sys._MEIPASS
    else:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, "assets", "logotipo.png")


class EcraLogin(ctk.CTkFrame):

    def __init__(self, parent, callback_login):
        super().__init__(parent, fg_color=CORES["bg_principal"], corner_radius=0)
        self._callback_login   = callback_login
        self._mostrar_password = False
        self._imagem_logo      = None
        self._construir_ui()

    def _construir_ui(self):
        self.place(relx=0, rely=0, relwidth=1, relheight=1)

        fundo_esq = ctk.CTkFrame(self, fg_color=CORES["bg_principal"], corner_radius=0)
        fundo_esq.place(relx=0, rely=0, relwidth=0.5, relheight=1)

        fundo_dir = ctk.CTkFrame(self, fg_color=CORES["bg_secundario"], corner_radius=0)
        fundo_dir.place(relx=0.5, rely=0, relwidth=0.5, relheight=1)

        painel = ctk.CTkFrame(
            self, fg_color=CORES["bg_secundario"], corner_radius=20,
            border_width=1, border_color=CORES["borda_clara"],
            width=480, height=560)
        painel.place(relx=0.5, rely=0.5, anchor="center")
        painel.pack_propagate(False)
        self._construir_painel(painel)

    def _construir_painel(self, painel: ctk.CTkFrame):
        conteudo = ctk.CTkFrame(painel, fg_color="transparent")
        conteudo.pack(expand=True, padx=50, pady=40, fill="both")

        self._carregar_logo(conteudo)

        ctk.CTkLabel(conteudo, text="Bem-vindo",
                     font=ctk.CTkFont("Segoe UI", 26, "bold"),
                     text_color=CORES["texto"]).pack(pady=(0, 4))
        ctk.CTkLabel(conteudo, text="Inicia sessão para continuar",
                     font=ctk.CTkFont("Segoe UI", 13),
                     text_color=CORES["texto_muted"]).pack(pady=(0, 28))

        ctk.CTkLabel(conteudo, text="Nome de Utilizador",
                     font=ctk.CTkFont("Segoe UI", 13, "bold"),
                     text_color=CORES["texto_claro"], anchor="w").pack(fill="x")
        self._campo_username = ctk.CTkEntry(
            conteudo, height=46, fg_color=CORES["bg_input"],
            border_color=CORES["borda"], border_width=1,
            text_color=CORES["texto"], placeholder_text="ex: joao_silva",
            placeholder_text_color=CORES["texto_muted"],
            font=ctk.CTkFont("Segoe UI", 14), corner_radius=10)
        self._campo_username.pack(fill="x", pady=(6, 16))

        ctk.CTkLabel(conteudo, text="Palavra-Passe",
                     font=ctk.CTkFont("Segoe UI", 13, "bold"),
                     text_color=CORES["texto_claro"], anchor="w").pack(fill="x")
        frame_pw = ctk.CTkFrame(conteudo, fg_color="transparent")
        frame_pw.pack(fill="x", pady=(6, 6))

        self._campo_password = ctk.CTkEntry(
            frame_pw, height=46, fg_color=CORES["bg_input"],
            border_color=CORES["borda"], border_width=1,
            text_color=CORES["texto"], placeholder_text="Palavra-passe",
            placeholder_text_color=CORES["texto_muted"],
            font=ctk.CTkFont("Segoe UI", 14), corner_radius=10, show="•")
        self._campo_password.pack(side="left", fill="x", expand=True)

        self._btn_olho = ctk.CTkButton(
            frame_pw, text="👁", width=46, height=46,
            fg_color=CORES["bg_input"], hover_color=CORES["bg_card_hover"],
            text_color=CORES["texto_muted"], corner_radius=10,
            font=ctk.CTkFont("Segoe UI", 18),
            command=self._toggle_password)
        self._btn_olho.pack(side="left", padx=(6, 0))

        self._lbl_erro = ctk.CTkLabel(conteudo, text="",
                                      font=ctk.CTkFont("Segoe UI", 12),
                                      text_color=CORES["perigo"])
        self._lbl_erro.pack(pady=(4, 0))

        self._btn_entrar = ctk.CTkButton(
            conteudo, text="Entrar", height=50,
            fg_color=CORES["acento"], hover_color=CORES["acento_hover"],
            text_color=CORES["texto"], font=ctk.CTkFont("Segoe UI", 16, "bold"),
            corner_radius=12, command=self._tentar_login)
        self._btn_entrar.pack(fill="x", pady=(16, 0))

        self._campo_username.bind("<Return>", lambda e: self._tentar_login())
        self._campo_password.bind("<Return>", lambda e: self._tentar_login())

    def _carregar_logo(self, parent):
        caminho_logo = _get_logo_path()
        if os.path.exists(caminho_logo):
            try:
                img = Image.open(caminho_logo).convert("RGBA")
                img.thumbnail((200, 100), Image.LANCZOS)
                self._imagem_logo = ImageTk.PhotoImage(img)
                ctk.CTkLabel(parent, image=self._imagem_logo, text="").pack(pady=(0, 20))
                return
            except Exception:
                pass
        ctk.CTkLabel(parent, text="⬡ LOGO",
                     font=ctk.CTkFont("Segoe UI", 36, "bold"),
                     text_color=CORES["acento"]).pack(pady=(0, 20))

    def _toggle_password(self):
        self._mostrar_password = not self._mostrar_password
        self._campo_password.configure(show="" if self._mostrar_password else "•")
        self._btn_olho.configure(
            text_color=CORES["acento"] if self._mostrar_password else CORES["texto_muted"])

    def _tentar_login(self):
        username = self._campo_username.get().strip()
        password = self._campo_password.get().strip()
        if not username or not password:
            self._mostrar_erro("Por favor preenche todos os campos.")
            return
        utilizador = verificar_credenciais(username, password)
        if utilizador:
            self._lbl_erro.configure(text="")
            registar_inicio_sessao(utilizador["username"])
            self._callback_login(utilizador)
        else:
            self._mostrar_erro("Nome de utilizador ou palavra-passe incorretos.")
            self._campo_password.delete(0, "end")
            self._campo_password.focus()

    def _mostrar_erro(self, mensagem: str):
        self._lbl_erro.configure(text=f"⚠  {mensagem}")

    def limpar(self):
        self._campo_username.delete(0, "end")
        self._campo_password.delete(0, "end")
        self._lbl_erro.configure(text="")
        self._campo_username.focus()
