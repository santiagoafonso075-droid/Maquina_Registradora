# =============================================================
# views/historico.py — Ecrã de Histórico de Vendas
# =============================================================

import customtkinter as ctk
from tkinter import messagebox

from utils.data_manager import (
    obter_historico, eliminar_vendas,
    calcular_total_noite, calcular_total_geral,
    enviar_historico_email, email_configurado,
    obter_email_config, guardar_email_config,
)
from config import CORES
from views.widgets import Tooltip, bind_recursivo


class EcraHistorico(ctk.CTkFrame):

    def __init__(self, parent, callback_voltar, utilizador: dict = None):
        super().__init__(parent, fg_color=CORES["bg_principal"], corner_radius=0)
        self._callback_voltar = callback_voltar
        self._utilizador = utilizador
        self._seleccionados: set = set()
        self._frames_vendas: dict = {}
        self._construir_ui()

    def set_utilizador(self, utilizador: dict):
        self._utilizador = utilizador

    def _eh_admin(self) -> bool:
        return self._utilizador is not None and self._utilizador.get("role") == "admin"

    # ─── CONSTRUÇÃO DA UI ────────────────────────────────────

    def _construir_ui(self):
        self.place(relx=0, rely=0, relwidth=1, relheight=1)

        # Cabeçalho
        cab = ctk.CTkFrame(self, fg_color=CORES["bg_sidebar"],
                           corner_radius=0, height=70)
        cab.pack(fill="x")
        cab.pack_propagate(False)
        ctk.CTkLabel(cab, text="📋  Histórico de Vendas",
                     font=ctk.CTkFont("Segoe UI", 22, "bold"),
                     text_color=CORES["texto"]).place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkFrame(self, height=1, fg_color=CORES["borda"]).pack(fill="x")

        self._construir_cabecalho_tabela()

        # Lista scrollável
        self._scroll = ctk.CTkScrollableFrame(
            self, fg_color=CORES["bg_principal"],
            scrollbar_button_color=CORES["borda_clara"],
            scrollbar_button_hover_color=CORES["acento"],
            corner_radius=0)
        self._scroll.pack(fill="both", expand=True, padx=30, pady=(0, 0))

        # Rodapé
        rodape = ctk.CTkFrame(self, fg_color=CORES["bg_sidebar"],
                              corner_radius=0, height=80)
        rodape.pack(fill="x", side="bottom")
        rodape.pack_propagate(False)

        ctk.CTkFrame(rodape, height=1, fg_color=CORES["borda"]).pack(fill="x")

        inner_rodape = ctk.CTkFrame(rodape, fg_color="transparent")
        inner_rodape.pack(fill="both", expand=True)

        # Botão Voltar
        ctk.CTkButton(inner_rodape, text="← Voltar", width=130, height=44,
                      fg_color=CORES["bg_secundario"], hover_color=CORES["bg_card_hover"],
                      text_color=CORES["texto_claro"],
                      font=ctk.CTkFont("Segoe UI", 14, "bold"),
                      corner_radius=10,
                      command=self._ao_voltar).place(x=30, rely=0.5, anchor="w")

        # Botão Eliminar (admin)
        self._btn_eliminar = ctk.CTkButton(
            inner_rodape, text="🗑  Eliminar", width=140, height=44,
            fg_color=CORES["perigo"], hover_color=CORES["perigo_hover"],
            text_color=CORES["texto"],
            font=ctk.CTkFont("Segoe UI", 14, "bold"),
            corner_radius=10,
            command=self._eliminar_seleccionados)
        self._btn_eliminar.place(x=175, rely=0.5, anchor="w")
        self._btn_eliminar.place_forget()

        self._lbl_seleccao = ctk.CTkLabel(
            inner_rodape, text="",
            font=ctk.CTkFont("Segoe UI", 12),
            text_color=CORES["acento_claro"])
        self._lbl_seleccao.place(x=330, rely=0.5, anchor="w")

        # Botão Enviar Histórico (todos os utilizadores)
        self._btn_enviar = ctk.CTkButton(
            inner_rodape, text="📤  Enviar Histórico", width=190, height=44,
            fg_color=CORES["envio"], hover_color=CORES["envio_hover"],
            text_color=CORES["texto"],
            font=ctk.CTkFont("Segoe UI", 14, "bold"),
            corner_radius=10,
            command=self._ao_enviar_historico)
        self._btn_enviar.place(relx=0.5, rely=0.5, anchor="center")

        # Totais — noite e geral
        frame_totais = ctk.CTkFrame(inner_rodape, fg_color="transparent")
        frame_totais.place(relx=1.0, x=-30, rely=0.5, anchor="e")

        ctk.CTkLabel(frame_totais, text="Noite:",
                     font=ctk.CTkFont("Segoe UI", 12),
                     text_color=CORES["texto_muted"]).pack(side="left", padx=(0, 4))
        self._label_total_noite = ctk.CTkLabel(
            frame_totais, text="0,00 €",
            font=ctk.CTkFont("Segoe UI", 18, "bold"),
            text_color=CORES["sucesso"])
        self._label_total_noite.pack(side="left", padx=(0, 20))

        ctk.CTkLabel(frame_totais, text="Total Geral:",
                     font=ctk.CTkFont("Segoe UI", 12),
                     text_color=CORES["texto_muted"]).pack(side="left", padx=(0, 4))
        self._label_total_geral = ctk.CTkLabel(
            frame_totais, text="0,00 €",
            font=ctk.CTkFont("Segoe UI", 18, "bold"),
            text_color=CORES["acento_claro"])
        self._label_total_geral.pack(side="left")

    def _construir_cabecalho_tabela(self):
        cab_tab = ctk.CTkFrame(self, fg_color=CORES["bg_secundario"],
                               corner_radius=0, height=44)
        cab_tab.pack(fill="x", padx=30, pady=(16, 0))
        cab_tab.pack_propagate(False)

        colunas = [
            ("Nº",          60,  "center"),
            ("Utilizador",  200, "w"),
            ("Data / Hora", 220, "w"),
            ("Itens",        80, "center"),
            ("Desconto",    120, "e"),
            ("Total",       120, "e"),
        ]
        for titulo, largura, ancora in colunas:
            ctk.CTkLabel(cab_tab, text=titulo,
                         font=ctk.CTkFont("Segoe UI", 12, "bold"),
                         text_color=CORES["texto_muted"],
                         width=largura, anchor=ancora).pack(side="left", padx=8)

    # ─── CARREGAR HISTÓRICO ───────────────────────────────────

    def carregar(self, utilizador: dict = None):
        if utilizador is not None:
            self._utilizador = utilizador

        self._seleccionados.clear()
        self._frames_vendas.clear()

        for w in self._scroll.winfo_children():
            w.destroy()

        if self._eh_admin():
            self._btn_eliminar.place(x=175, rely=0.5, anchor="w")
            self._lbl_seleccao.configure(text="Clica numa linha para selecionar")
        else:
            self._btn_eliminar.place_forget()
            self._lbl_seleccao.configure(text="")

        historico = obter_historico()

        # Remover marcadores fim_dia orfaos (sem vendas entre eles)
        historico = self._limpar_marcadores_orfaos(historico)

        tem_vendas = any(e.get("tipo", "venda") == "venda" for e in historico)
        if not tem_vendas:
            ctk.CTkLabel(self._scroll, text="Ainda não há vendas registadas.",
                         font=ctk.CTkFont("Segoe UI", 16),
                         text_color=CORES["texto_muted"]).pack(pady=60)
            self._label_total_noite.configure(text="0,00 €")
            self._label_total_geral.configure(text="0,00 €")
            return

        total_noite = calcular_total_noite(historico)
        total_geral = calcular_total_geral(historico)
        self._label_total_noite.configure(text=f"{total_noite:.2f} €")
        self._label_total_geral.configure(text=f"{total_geral:.2f} €")

        lista = list(reversed(historico))
        self._renderizar_lista(lista)

    @staticmethod
    def _limpar_marcadores_orfaos(historico: list) -> list:
        """
        Remove marcadores fim_dia que nao tem nenhuma venda entre si e o
        marcador anterior (ou o inicio/fim da lista).
        """
        resultado = []
        for entrada in historico:
            if entrada.get("tipo") == "fim_dia":
                # Contar vendas desde o ultimo fim_dia no resultado acumulado
                vendas_desde_ultimo = 0
                for e in reversed(resultado):
                    if e.get("tipo") == "fim_dia":
                        break
                    if e.get("tipo", "venda") == "venda":
                        vendas_desde_ultimo += 1
                if vendas_desde_ultimo > 0:
                    resultado.append(entrada)
            else:
                resultado.append(entrada)

        # Remover fim_dia no final sem vendas depois deles
        while resultado and resultado[-1].get("tipo") == "fim_dia":
            resultado.pop()

        return resultado

    def _renderizar_lista(self, lista_invertida: list):
        """
        A lista está invertida (mais recente primeiro).
        Histórico cronológico:  v1  v2  fim_dia  v3  v4
        Lista invertida:        v4  v3  fim_dia  v2  v1

        Queremos mostrar de cima para baixo:
          vendas recentes (v4, v3)
          ── separador dia ──
          vendas antigas (v2, v1)

        Ou seja: percorremos a lista invertida e sempre que encontramos
        um fim_dia, primeiro descarregamos as vendas acumuladas (mais recentes),
        depois o separador, e continuamos com as seguintes (mais antigas).
        """
        blocos = []
        acumuladas = []

        for entrada in lista_invertida:
            if entrada.get("tipo") == "fim_dia":
                if acumuladas:
                    blocos.append(("vendas", self._agrupar_por_utilizador(acumuladas)))
                    acumuladas = []
                blocos.append(("separador", entrada))
            else:
                acumuladas.append(entrada)

        if acumuladas:
            blocos.append(("vendas", self._agrupar_por_utilizador(acumuladas)))

        for bloco in blocos:
            if bloco[0] == "vendas":
                for nome_grupo, vendas_grupo, total_grupo in bloco[1]:
                    self._criar_separador_utilizador(nome_grupo, total_grupo)
                    for venda in vendas_grupo:
                        self._criar_linha_venda(venda)
            else:
                self._criar_separador_dia(bloco[1])

    def _agrupar_por_utilizador(self, vendas: list):
        """
        Agrupa vendas por blocos CONTÍGUOS do mesmo utilizador.
        Ex: [A, A, B, A] → [(A,[v1,v2],total), (B,[v3],total), (A,[v4],total)]
        Retorna [(nome, [vendas], total), ...]
        """
        if not vendas:
            return []

        grupos = []
        nome_atual = vendas[0].get("utilizador", "?")
        bloco_atual = [vendas[0]]

        for venda in vendas[1:]:
            nome = venda.get("utilizador", "?")
            if nome == nome_atual:
                bloco_atual.append(venda)
            else:
                total = round(sum(v.get("total", 0.0) for v in bloco_atual), 2)
                grupos.append((nome_atual, bloco_atual, total))
                nome_atual = nome
                bloco_atual = [venda]

        # último bloco
        total = round(sum(v.get("total", 0.0) for v in bloco_atual), 2)
        grupos.append((nome_atual, bloco_atual, total))
        return grupos

    def _criar_separador_utilizador(self, nome: str, total: float):
        frame = ctk.CTkFrame(self._scroll, fg_color="transparent", height=32)
        frame.pack(fill="x", pady=(8, 2))
        frame.pack_propagate(False)

        ctk.CTkFrame(frame, height=1, fg_color=CORES["borda_clara"]).place(
            relx=0, rely=0.5, relwidth=0.22, anchor="w")

        label_texto = f"  👤  {nome}   →   {total:.2f} €  "
        ctk.CTkLabel(frame, text=label_texto,
                     font=ctk.CTkFont("Segoe UI", 11, "bold"),
                     text_color=CORES["acento_claro"],
                     fg_color=CORES["bg_principal"],
                     corner_radius=6).place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkFrame(frame, height=1, fg_color=CORES["borda_clara"]).place(
            relx=1.0, rely=0.5, relwidth=0.22, anchor="e")

    def _criar_separador_dia(self, marcador: dict):
        """Linha divisória horizontal com data e total do dia."""
        data   = marcador.get("data", "")
        total  = marcador.get("total_dia", 0.0)

        frame = ctk.CTkFrame(self._scroll, fg_color="transparent", height=38)
        frame.pack(fill="x", pady=(10, 2))
        frame.pack_propagate(False)

        # Linha tracejada visual: frame horizontal com label ao centro
        linha_frame = ctk.CTkFrame(frame, fg_color=CORES["borda_clara"],
                                   height=2, corner_radius=0)
        linha_frame.place(relx=0, rely=0.5, relwidth=1, anchor="w")

        texto = f"  DIA {data}  →  {total:.2f} €  "
        ctk.CTkLabel(frame, text=texto,
                     font=ctk.CTkFont("Segoe UI", 12, "bold"),
                     text_color=CORES["desconto"],
                     fg_color=CORES["bg_principal"],
                     corner_radius=6).place(relx=0.5, rely=0.5, anchor="center")

    def _criar_linha_venda(self, venda: dict):
        total_desconto = sum(venda.get("descontos", []))
        n_itens        = sum(i.get("quantidade", 1) for i in venda.get("itens", []))
        venda_id       = venda["id"]

        frame = ctk.CTkFrame(self._scroll, fg_color=CORES["bg_item"],
                             corner_radius=8, height=50)
        frame.pack(fill="x", pady=3)
        frame.pack_propagate(False)

        self._frames_vendas[venda_id] = frame

        dados = [
            (f"#{venda['id']}",  60,  "center", CORES["acento_claro"], False),
            (venda["utilizador"], 200, "w",      CORES["texto_claro"],  False),
            (venda["data_hora"],  220, "w",      CORES["texto_muted"],  False),
            (str(n_itens),         80, "center", CORES["texto_claro"],  False),
            (f"-{total_desconto:.2f} €" if total_desconto > 0 else "—",
                                  120, "e",
                                  CORES["desconto"] if total_desconto > 0 else CORES["texto_muted"],
                                  False),
            (f"{venda['total']:.2f} €", 120, "e", CORES["sucesso"], True),
        ]

        for texto, largura, ancora, cor, negrito in dados:
            ctk.CTkLabel(frame, text=texto,
                         font=ctk.CTkFont("Segoe UI", 13, "bold" if negrito else "normal"),
                         text_color=cor, width=largura,
                         anchor=ancora).pack(side="left", padx=8)

        Tooltip(frame, self._formatar_tooltip(venda))

        def _entrar(e, f=frame, vid=venda_id):
            if vid not in self._seleccionados:
                f.configure(fg_color=CORES["bg_item_hover"])

        def _sair(e, f=frame, vid=venda_id):
            if vid not in self._seleccionados:
                f.configure(fg_color=CORES["bg_item"])

        def _clicar(e, f=frame, vid=venda_id):
            if not self._eh_admin():
                return
            if vid in self._seleccionados:
                self._seleccionados.discard(vid)
                f.configure(fg_color=CORES["bg_item"], border_width=0)
            else:
                self._seleccionados.add(vid)
                f.configure(fg_color=CORES["selecionado"],
                             border_width=2,
                             border_color=CORES["selecionado_borda"])
            self._atualizar_label_seleccao()

        bind_recursivo(frame, "<Enter>",    _entrar)
        bind_recursivo(frame, "<Leave>",    _sair)
        bind_recursivo(frame, "<Button-1>", _clicar)

    def _atualizar_label_seleccao(self):
        n = len(self._seleccionados)
        if n == 0:
            self._lbl_seleccao.configure(text="Clica numa linha para selecionar")
        elif n == 1:
            self._lbl_seleccao.configure(text="1 registo selecionado")
        else:
            self._lbl_seleccao.configure(text=f"{n} registos selecionados")

    def _eliminar_seleccionados(self):
        if not self._seleccionados:
            messagebox.showinfo("Sem seleção",
                                "Seleciona pelo menos um registo para eliminar.",
                                parent=self)
            return

        n = len(self._seleccionados)
        confirmar = messagebox.askyesno(
            "Confirmar eliminação",
            f"Tens a certeza que queres eliminar {n} registo{'s' if n > 1 else ''}?\n"
            "Esta ação não pode ser desfeita.",
            parent=self)

        if confirmar:
            eliminar_vendas(list(self._seleccionados))
            self.carregar(self._utilizador)

    def _ao_voltar(self):
        self._seleccionados.clear()
        self._callback_voltar()

    @staticmethod
    def _formatar_tooltip(venda: dict) -> str:
        linhas = [f"Venda #{venda['id']} — {venda['utilizador']}", ""]
        for item in venda.get("itens", []):
            qtd   = item.get("quantidade", 1)
            preco = item.get("preco_unit", 0)
            linhas.append(f"  {qtd}x {item['nome']}  ({preco:.2f} €)")
        descontos = venda.get("descontos", [])
        if descontos:
            linhas.append("")
            for d in descontos:
                linhas.append(f"  Desconto: -{d:.2f} €")
        linhas += ["", f"  Total: {venda['total']:.2f} €"]
        return "\n".join(linhas)

    # ─── ENVIO DE HISTÓRICO ───────────────────────────────────

    def _ao_enviar_historico(self):
        """Lógica do botão Enviar Histórico."""
        # Admin sem email configurado → abre modal de configuração
        if self._eh_admin() and not email_configurado():
            self._abrir_modal_config_email()
            return

        # Qualquer utilizador com email configurado
        if not email_configurado():
            messagebox.showwarning(
                "Email não configurado",
                "O envio de histórico ainda não foi configurado.\n"
                "Pede ao administrador para configurar o email.",
                parent=self)
            return

        confirmar = messagebox.askyesno(
            "Enviar Histórico",
            "Vais enviar o histórico completo por email.\n\n"
            "⚠  Após o envio, o histórico local será apagado.\n\n"
            "Tens a certeza?",
            parent=self)

        if not confirmar:
            return

        self._btn_enviar.configure(state="disabled", text="A enviar...")
        self.update()

        utilizador = self._utilizador.get("username", "?") if self._utilizador else "?"
        sucesso, mensagem = enviar_historico_email(utilizador)

        self._btn_enviar.configure(state="normal", text="📤  Enviar Histórico")

        if sucesso:
            messagebox.showinfo("Enviado!", mensagem, parent=self)
            self.carregar(self._utilizador)
        else:
            messagebox.showerror("Erro no envio", mensagem, parent=self)

    def _abrir_modal_config_email(self):
        """Modal de configuração de email (apenas admin)."""
        modal = ctk.CTkToplevel(self)
        modal.title("Configurar Envio de Email")
        modal.geometry("520x420")
        modal.resizable(False, False)
        modal.grab_set()
        modal.configure(fg_color=CORES["bg_secundario"])

        ctk.CTkLabel(modal, text="⚙  Configurar Email de Envio",
                     font=ctk.CTkFont("Segoe UI", 18, "bold"),
                     text_color=CORES["texto"]).pack(pady=(28, 4))

        ctk.CTkLabel(modal,
                     text="Usa um Gmail dedicado à app com uma App Password do Google.",
                     font=ctk.CTkFont("Segoe UI", 12),
                     text_color=CORES["texto_muted"]).pack(pady=(0, 20))

        cfg = obter_email_config()

        frame_campos = ctk.CTkFrame(modal, fg_color="transparent")
        frame_campos.pack(fill="x", padx=40)

        def _campo(label_texto, valor_inicial, show=""):
            ctk.CTkLabel(frame_campos, text=label_texto,
                         font=ctk.CTkFont("Segoe UI", 12, "bold"),
                         text_color=CORES["texto_claro"], anchor="w").pack(fill="x")
            entrada = ctk.CTkEntry(
                frame_campos, height=42, fg_color=CORES["bg_input"],
                border_color=CORES["borda"], border_width=1,
                text_color=CORES["texto"],
                font=ctk.CTkFont("Segoe UI", 13),
                corner_radius=8, show=show)
            entrada.insert(0, valor_inicial)
            entrada.pack(fill="x", pady=(4, 14))
            return entrada

        campo_remetente    = _campo("Email Remetente (Gmail da app)", cfg.get("email_remetente", ""))
        campo_password     = _campo("App Password", cfg.get("app_password", ""), show="•")
        campo_destinatario = _campo("Email Destinatário (o teu email)", cfg.get("email_destinatario", ""))

        lbl_estado = ctk.CTkLabel(modal, text="",
                                  font=ctk.CTkFont("Segoe UI", 12),
                                  text_color=CORES["sucesso"])
        lbl_estado.pack(pady=(0, 8))

        def _guardar():
            rem  = campo_remetente.get().strip()
            pwd  = campo_password.get().strip()
            dest = campo_destinatario.get().strip()
            if not rem or not pwd or not dest:
                lbl_estado.configure(text="⚠  Preenche todos os campos.", text_color=CORES["perigo"])
                return
            guardar_email_config(rem, pwd, dest)
            lbl_estado.configure(text="✓  Configuração guardada!", text_color=CORES["sucesso"])
            modal.after(1200, modal.destroy)

        ctk.CTkButton(modal, text="Guardar", height=44, width=200,
                      fg_color=CORES["acento"], hover_color=CORES["acento_hover"],
                      text_color=CORES["texto"],
                      font=ctk.CTkFont("Segoe UI", 14, "bold"),
                      corner_radius=10,
                      command=_guardar).pack(pady=(0, 20))
