# =============================================================
# utils/data_manager.py — Gestor de Dados
# =============================================================

import json
import os
import sys
import smtplib
import shutil
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime

# ─── BASE PATH (funciona compilado com PyInstaller) ──────────
def _get_base() -> str:
    if getattr(sys, "frozen", False):
        return sys._MEIPASS
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_BASE = _get_base()

CAMINHO_UTILIZADORES = os.path.join(_BASE, "data", "utilizadores.json")
CAMINHO_PRODUTOS     = os.path.join(_BASE, "data", "produtos.json")
CAMINHO_HISTORICO    = os.path.join(_BASE, "data", "historico.json")
CAMINHO_EMAIL_CONFIG = os.path.join(_BASE, "data", "email_config.json")


# ─── FUNÇÕES INTERNAS ────────────────────────────────────────

def _ler_json(caminho: str):
    with open(caminho, "r", encoding="utf-8") as f:
        return json.load(f)


def _escrever_json(caminho: str, dados):
    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=4)


# ─── UTILIZADORES ────────────────────────────────────────────

def verificar_credenciais(username: str, password: str):
    utilizadores = _ler_json(CAMINHO_UTILIZADORES)
    for u in utilizadores:
        if u["username"] == username and u["password"] == password:
            return u
    return None


# ─── PRODUTOS ────────────────────────────────────────────────

def obter_todos_produtos() -> dict:
    return _ler_json(CAMINHO_PRODUTOS)


def obter_produtos_categoria(categoria: str) -> list:
    return obter_todos_produtos().get(categoria, [])


def adicionar_produto(categoria: str, nome: str, preco: float, imagem: str = "") -> dict:
    todos = obter_todos_produtos()
    max_id = 0
    for lista in todos.values():
        for p in lista:
            if isinstance(p, dict) and p.get("id", 0) > max_id:
                max_id = p["id"]

    novo = {
        "id":     max_id + 1,
        "nome":   nome.strip(),
        "preco":  round(float(preco), 2),
        "imagem": imagem.strip(),
    }

    if categoria not in todos:
        todos[categoria] = []
    todos[categoria].append(novo)
    _escrever_json(CAMINHO_PRODUTOS, todos)
    return novo


def adicionar_produto_mistura(categoria: str, nome: str, subtipo: str, imagem: str = "") -> dict:
    todos = obter_todos_produtos()
    max_id = 0
    for lista in todos.values():
        for p in lista:
            if isinstance(p, dict) and p.get("id", 0) > max_id:
                max_id = p["id"]

    novo = {
        "id":      max_id + 1,
        "nome":    nome.strip(),
        "preco":   4.00,
        "subtipo": subtipo,
        "imagem":  imagem.strip(),
    }

    if categoria not in todos:
        todos[categoria] = []
    todos[categoria].append(novo)
    _escrever_json(CAMINHO_PRODUTOS, todos)
    return novo


def guardar_todos_produtos(produtos: dict):
    _escrever_json(CAMINHO_PRODUTOS, produtos)


# ─── HISTÓRICO DE VENDAS ─────────────────────────────────────

def obter_historico() -> list:
    return _ler_json(CAMINHO_HISTORICO)


def guardar_venda(utilizador: str, itens: list, descontos: list, total: float) -> dict:
    historico = obter_historico()

    # Procurar último ID (ignorar entradas de "fim de dia")
    ultimo_id = 0
    for entrada in historico:
        if entrada.get("tipo") != "fim_dia" and entrada.get("id", 0) > ultimo_id:
            ultimo_id = entrada["id"]

    nova_venda = {
        "id":         ultimo_id + 1,
        "tipo":       "venda",
        "utilizador": utilizador,
        "data_hora":  datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
        "itens":      itens,
        "descontos":  descontos,
        "total":      round(total, 2),
    }

    historico.append(nova_venda)
    _escrever_json(CAMINHO_HISTORICO, historico)
    return nova_venda


def fechar_dia(utilizador: str) -> dict:
    """
    Insere um marcador de fim de dia no histórico.
    Calcula o total das vendas do dia atual (desde o último fim_dia ou início).
    """
    historico = obter_historico()

    # Calcular total desde o último fim_dia
    total_dia = 0.0
    for entrada in reversed(historico):
        if entrada.get("tipo") == "fim_dia":
            break
        if entrada.get("tipo", "venda") == "venda":
            total_dia += entrada.get("total", 0.0)

    agora = datetime.now()
    marcador = {
        "tipo":       "fim_dia",
        "data":       agora.strftime("%d/%m/%Y"),
        "data_hora":  agora.strftime("%d/%m/%Y %H:%M:%S"),
        "utilizador": utilizador,
        "total_dia":  round(total_dia, 2),
    }

    historico.append(marcador)
    _escrever_json(CAMINHO_HISTORICO, historico)
    return marcador


def eliminar_vendas(ids: list):
    """Remove do histórico as vendas cujos IDs estão na lista."""
    historico = obter_historico()
    ids_set = set(ids)
    historico_filtrado = [v for v in historico if v.get("id") not in ids_set]
    _escrever_json(CAMINHO_HISTORICO, historico_filtrado)


def calcular_total_noite(historico: list) -> float:
    """
    Total da 'noite atual': vendas desde o último fim_dia (ou todas se nunca houve).
    """
    total = 0.0
    for entrada in reversed(historico):
        if entrada.get("tipo") == "fim_dia":
            break
        if entrada.get("tipo", "venda") == "venda":
            total += entrada.get("total", 0.0)
    return round(total, 2)


def calcular_total_geral(historico: list) -> float:
    """Total de todas as vendas (ignora marcadores fim_dia)."""
    return round(sum(
        e.get("total", 0.0)
        for e in historico
        if e.get("tipo", "venda") == "venda"
    ), 2)


# ─── INÍCIO DE SESSÃO ────────────────────────────────────────

def registar_inicio_sessao(utilizador: str):
    """
    Insere um marcador de início de sessão no histórico.
    Só regista se não houver já um marcador de início de sessão
    do mesmo utilizador sem vendas depois (evita duplicados em
    caso de login repetido sem actividade).
    """
    historico = obter_historico()

    # Verificar se o último evento deste utilizador já é um inicio_sessao
    for entrada in reversed(historico):
        tipo = entrada.get("tipo")
        if tipo == "venda" and entrada.get("utilizador") == utilizador:
            break  # Há vendas desde o último login → regista novo
        if tipo == "inicio_sessao" and entrada.get("utilizador") == utilizador:
            return  # Já tem início de sessão sem vendas → não duplica

    marcador = {
        "tipo":       "inicio_sessao",
        "utilizador": utilizador,
        "data_hora":  datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
    }
    historico.append(marcador)
    _escrever_json(CAMINHO_HISTORICO, historico)


def obter_hora_abertura_sessao(utilizador: str) -> str:
    """
    Devolve a hora do início de sessão mais recente do utilizador.
    Se não existir registo, usa a hora da primeira venda do utilizador
    no histórico actual. Fallback: hora actual.
    """
    historico = obter_historico()

    # Procurar o marcador inicio_sessao mais recente do utilizador
    for entrada in reversed(historico):
        if entrada.get("tipo") == "inicio_sessao" and entrada.get("utilizador") == utilizador:
            return entrada["data_hora"].split(" ")[1][:5]  # "HH:MM"

    # Fallback: hora da primeira venda
    for entrada in historico:
        if entrada.get("tipo", "venda") == "venda" and entrada.get("utilizador") == utilizador:
            return entrada["data_hora"].split(" ")[1][:5]

    return datetime.now().strftime("%H:%M")


# ─── CONFIGURAÇÃO DE EMAIL ───────────────────────────────────

def obter_email_config() -> dict:
    """Lê a configuração de email. Devolve dicionário com as chaves."""
    try:
        return _ler_json(CAMINHO_EMAIL_CONFIG)
    except Exception:
        return {"email_remetente": "", "app_password": "", "email_destinatario": ""}


def guardar_email_config(email_remetente: str, app_password: str, email_destinatario: str):
    """Guarda as configurações de email."""
    config = {
        "email_remetente":   email_remetente.strip(),
        "app_password":      app_password.strip(),
        "email_destinatario": email_destinatario.strip(),
    }
    _escrever_json(CAMINHO_EMAIL_CONFIG, config)


def email_configurado() -> bool:
    """Retorna True se o email já estiver configurado."""
    cfg = obter_email_config()
    return bool(cfg.get("email_remetente") and cfg.get("app_password") and cfg.get("email_destinatario"))


# ─── ENVIO DO HISTÓRICO ──────────────────────────────────────

def enviar_historico_email(utilizador: str) -> tuple[bool, str]:
    """
    Envia o historico.json por email, renomeia o ficheiro e apaga o histórico local.
    Devolve (sucesso: bool, mensagem: str).
    """
    import tempfile

    cfg = obter_email_config()
    email_remetente    = cfg.get("email_remetente", "")
    app_password       = cfg.get("app_password", "")
    email_destinatario = cfg.get("email_destinatario", "")

    if not email_remetente or not app_password or not email_destinatario:
        return False, "Email não configurado. Pede ao administrador para configurar o envio."

    historico = obter_historico()
    if not any(e.get("tipo", "venda") == "venda" for e in historico):
        return False, "Não há vendas para enviar."

    # Calcular nome do ficheiro
    agora        = datetime.now()
    data_str     = agora.strftime("%Y-%m-%d")
    hora_fecho   = agora.strftime("%H:%M")
    hora_abertura = obter_hora_abertura_sessao(utilizador)
    nome_ficheiro = f"{data_str}_{utilizador}_{hora_abertura.replace(':', '')}_{hora_fecho.replace(':', '')}.json"

    # Criar ficheiro temporário com o nome correcto
    tmp_dir  = tempfile.mkdtemp()
    tmp_path = os.path.join(tmp_dir, nome_ficheiro)
    shutil.copy2(CAMINHO_HISTORICO, tmp_path)

    try:
        # Construir email
        msg = MIMEMultipart()
        msg["From"]    = email_remetente
        msg["To"]      = email_destinatario
        msg["Subject"] = f"Histórico de Vendas — {utilizador} — {data_str}"

        corpo = (
            f"Histórico de vendas enviado por: {utilizador}\n"
            f"Data: {data_str}\n"
            f"Hora de abertura: {hora_abertura}\n"
            f"Hora de fecho: {hora_fecho}\n\n"
            f"Ficheiro em anexo: {nome_ficheiro}"
        )
        msg.attach(MIMEText(corpo, "plain", "utf-8"))

        # Anexar ficheiro
        with open(tmp_path, "rb") as f:
            parte = MIMEBase("application", "octet-stream")
            parte.set_payload(f.read())
        encoders.encode_base64(parte)
        parte.add_header("Content-Disposition", f'attachment; filename="{nome_ficheiro}"')
        msg.attach(parte)

        # Enviar via Gmail SMTP
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as servidor:
            servidor.login(email_remetente, app_password)
            servidor.sendmail(email_remetente, email_destinatario, msg.as_string())

        # Limpar histórico local
        _escrever_json(CAMINHO_HISTORICO, [])

        return True, f"Histórico enviado com sucesso para {email_destinatario}."

    except smtplib.SMTPAuthenticationError:
        return False, "Erro de autenticação. Verifica o email e a App Password."
    except smtplib.SMTPException as e:
        return False, f"Erro de envio: {e}"
    except Exception as e:
        return False, f"Erro inesperado: {e}"
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)
