# =============================================================
# config.py — Configurações Gerais da Aplicação
# =============================================================

# ─── DIMENSÕES DA JANELA ──────────────────────────────────────
LARGURA  = 1920
ALTURA   = 1080

# ─── PALETA DE CORES ─────────────────────────────────────────
CORES = {
    # Fundos principais
    "bg_principal":    "#0A1628",
    "bg_secundario":   "#0D1E36",
    "bg_card":         "#112035",
    "bg_card_hover":   "#1A3050",
    "bg_sidebar":      "#060F1E",
    "bg_topbar":       "#0B1929",
    "bg_lista":        "#0C1B30",
    "bg_item":         "#112035",
    "bg_item_hover":   "#1A3050",
    "bg_input":        "#1A2B42",
    "bg_overlay":      "#00000099",
    "bg_modal":        "#0D1E36",

    # Acentos azuis
    "acento":          "#1E6FD9",
    "acento_hover":    "#2980E8",
    "acento_claro":    "#4DABF7",
    "acento_brilho":   "#74C0FC",

    # Texto
    "texto":           "#FFFFFF",
    "texto_claro":     "#D4E5F7",
    "texto_muted":     "#6B8CAE",

    # Botões de ação
    "sucesso":         "#1A9E5C",
    "sucesso_hover":   "#22C870",
    "perigo":          "#C0392B",
    "perigo_hover":    "#E74C3C",
    "desconto":        "#D68910",
    "desconto_hover":  "#F39C12",

    # Bordas
    "borda":           "#1A3050",
    "borda_clara":     "#2D6099",

    # Botão categoria selecionada
    "cat_ativa":       "#1E6FD9",
    "cat_inativa":     "#0D1E36",

    # Misturas — secção alcoólica
    "mix_alc_bg":      "#1A0A2E",
    "mix_alc_header":  "#4A1580",
    "mix_alc_card":    "#2A1248",
    "mix_alc_hover":   "#3D1A6A",
    "mix_alc_borda":   "#7B2FBE",

    # Misturas — secção não alcoólica
    "mix_nalc_bg":     "#0A1E12",
    "mix_nalc_header": "#0F5C28",
    "mix_nalc_card":   "#122B1A",
    "mix_nalc_hover":  "#1A4228",
    "mix_nalc_borda":  "#27AE60",

    # Selecionado (histórico admin)
    "selecionado":     "#1A3A5C",
    "selecionado_borda": "#4DABF7",

    # Envio de histórico
    "envio":           "#0E6655",
    "envio_hover":     "#17A589",
}

# ─── FONTES ──────────────────────────────────────────────────
FONTES = {
    "titulo_grande":  ("Segoe UI", 30, "bold"),
    "titulo":         ("Segoe UI", 22, "bold"),
    "subtitulo":      ("Segoe UI", 17, "bold"),
    "normal_bold":    ("Segoe UI", 14, "bold"),
    "normal":         ("Segoe UI", 14),
    "pequeno_bold":   ("Segoe UI", 12, "bold"),
    "pequeno":        ("Segoe UI", 12),
    "minusculo":      ("Segoe UI", 10),
}

# ─── DESCONTOS DISPONÍVEIS (€) ───────────────────────────────
DESCONTOS = [0.25, 0.50, 1.00]

# ─── CATEGORIAS ──────────────────────────────────────────────
# "Cocktails" substitui "Copas"
# "Misturas" tem comportamento especial (par alcoólico + não alcoólico)
CATEGORIAS = ["Bebidas s/Álcool", "Bebidas c/Álcool", "Cocktails", "Shots", "Comida", "Caipiroska", "Misturas"]

# Categoria especial que requer seleção de par
CATEGORIA_MISTURAS = "Misturas"
PRECO_MISTURA = 4.00

# ─── DIMENSÕES DO LAYOUT ────────────────────────────────────
LARGURA_SIDEBAR      = 200
ALTURA_TOPBAR        = 65
LARGURA_PAINEL_ACOES = 80
LARGURA_LISTA        = 520

# ─── CARDS DE PRODUTO ───────────────────────────────────────
TAMANHO_CARD    = 190
COLUNAS_CATALOG = 4

# ─── GRADIENTES DOS PLACEHOLDERS POR CATEGORIA ──────────────
GRADIENTES_CATEGORIA = {
    "Cocktails":  ((13,  71,  161), (33,  150, 243)),  # Azul
    "Shots":      ((74,  20,  140), (156, 39,  176)),  # Roxo
    "Comida":            ((183, 28,  28),  (229, 57,  53 )),  # Vermelho
    "Bebidas s/Álcool":  ((0,   140, 180), (0,   210, 240)),  # Ciano
    "Bebidas c/Álcool":  ((160, 50,  0  ), (220, 100, 30 )),  # Âmbar
    "Caipiroska": ((0,   110, 55 ), (30,  180, 100)),  # Verde
    "Misturas":   ((80,  20,  120), (140, 60,  200)),  # Violeta
}
